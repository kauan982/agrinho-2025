let farmer;
let tiles = [];
let cols = 5;
let rows = 5;
let tileSize = 80;
let score = 0;

function setup() {
  createCanvas(cols * tileSize, rows * tileSize + 50);
  farmer = new Farmer(2, 2);

  for (let y = 0; y < rows; y++) {
    tiles[y] = [];
    for (let x = 0; x < cols; x++) {
      tiles[y][x] = new Tile(x, y);
    }
  }
}

function draw() {
  background(100, 200, 100);

  // Desenhar os tiles
  for (let row of tiles) {
    for (let tile of row) {
      tile.update();
      tile.display();
    }
  }

  // Desenhar o fazendeiro
  farmer.display();

  // Mostrar pontuação
  fill(0);
  textSize(20);
  text(`Colheitas: ${score}`, 10, height - 30);
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) farmer.move(-1, 0);
  if (keyCode === RIGHT_ARROW) farmer.move(1, 0);
  if (keyCode === UP_ARROW) farmer.move(0, -1);
  if (keyCode === DOWN_ARROW) farmer.move(0, 1);

  let currentTile = tiles[farmer.y][farmer.x];

  if (key === 'p' || key === 'P') {
    currentTile.plant();
  } else if (key === 'r' || key === 'R') {
    currentTile.water();
  } else if (key === 'c' || key === 'C') {
    if (currentTile.harvest()) {
      score++;
    }
  }
}

// Classe do fazendeiro
class Farmer {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  move(dx, dy) {
    this.x = constrain(this.x + dx, 0, cols - 1);
    this.y = constrain(this.y + dy, 0, rows - 1);
  }

  display() {
    fill(0, 0, 255);
    rect(this.x * tileSize + 20, this.y * tileSize + 20, tileSize - 40, tileSize - 40);
  }
}

// Classe dos tiles (espaços de plantação)
class Tile {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.state = 'empty'; // empty, planted, growing, ready
    this.timer = 0;
  }

  plant() {
    if (this.state === 'empty') {
      this.state = 'planted';
      this.timer = 0;
    }
  }

  water() {
    if (this.state === 'planted' || this.state === 'growing') {
      this.timer += 20; // acelerar o crescimento
    }
  }

  harvest() {
    if (this.state === 'ready') {
      this.state = 'empty';
      this.timer = 0;
      return true;
    }
    return false;
  }

  update() {
    if (this.state === 'planted' || this.state === 'growing') {
      this.timer++;
      if (this.timer > 200) {
        this.state = 'ready';
      } else if (this.timer > 100) {
        this.state = 'growing';
      }
    }
  }

  display() {
    stroke(0);
    fill(139, 69, 19);
    rect(this.x * tileSize, this.y * tileSize, tileSize, tileSize);

    if (this.state === 'planted') {
      fill(0, 200, 0);
      ellipse(this.x * tileSize + tileSize / 2, this.y * tileSize + tileSize / 2, 10);
    } else if (this.state === 'growing') {
      fill(0, 150, 0);
      ellipse(this.x * tileSize + tileSize / 2, this.y * tileSize + tileSize / 2, 20);
    } else if (this.state === 'ready') {
      fill(255, 215, 0);
      ellipse(this.x * tileSize + tileSize / 2, this.y * tileSize + tileSize / 2, 30);
    }
  }
}
